package com.example.otp_verify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {
   TextInputLayout username,password,confirmpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        confirmpassword = findViewById(R.id.confirmpass);
    }
    public void Otppage(View view) {
        String user = username.getEditText().getText().toString();
        String pass1  = password.getEditText().getText().toString();
        String pass2 = confirmpassword.getEditText().getText().toString();
       if(TextUtils.isEmpty(user)){
           username.setError("This Cant be Empty");
           return ;
       }
       else if (user.length()>12){
           username.setError("Username More than 12");
           return ;
       }
       else if(TextUtils.isEmpty(pass1)){
            password.setError("Password Cant be Empty");
            return ;
        }
       else  if(TextUtils.isEmpty(pass2)){
            confirmpassword.setError("Confirm Password Cant be Empty");
            return ;
        }
       else if(!pass1.equals(pass2)){
           confirmpassword.setError("Password Do not Match");
           return ;
       }
       Intent intent = new Intent(MainActivity.this,otp_request.class);
       intent.putExtra("name",user);
       startActivity(intent);
       finish();
    }
}
