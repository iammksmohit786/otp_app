package com.example.otp_verify;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Size;
import android.widget.TextView;

public class MyApp extends AppCompatActivity {
    TextView welcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_app);
        welcome = findViewById(R.id.welcomeuser);
        String userkaname = getIntent().getStringExtra("key");
        welcome.setText("Welcome"+"\n"+"\n"+userkaname);
        welcome.setTextColor(Color.BLUE);
    }
}
