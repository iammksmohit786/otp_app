package com.example.otp_verify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;

public class otp_request extends AppCompatActivity {
    TextInputLayout otp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_request);
        otp = findViewById(R.id.otptext);
    }
    public void gotomain(View view) {
        String otptext = otp.getEditText().getText().toString();
        if(TextUtils.isEmpty(otptext)){
            otp.setError("This Cant be Empty");
            return;
        }
        String name  = getIntent().getStringExtra("name");
        Intent intent = new Intent(otp_request.this,MyApp.class);
        intent.putExtra("key",name);
        startActivity(intent);
        finish();
    }
}
